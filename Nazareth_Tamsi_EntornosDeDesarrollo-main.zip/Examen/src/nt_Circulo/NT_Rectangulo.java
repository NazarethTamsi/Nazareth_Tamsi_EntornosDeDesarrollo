package nt_Circulo;

public class NT_Rectangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
